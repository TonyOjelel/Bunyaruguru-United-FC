<?php
// This theme requires WordPress 5.6 or later.
if ( version_compare( $GLOBALS['wp_version'], '5.6', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! function_exists( 'vensica_setup' ) ) {

	function vensica_setup() {

		load_theme_textdomain( 'vensica', get_template_directory() . '/languages' );

		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support(
			'post-formats',
			array(
				'link', 'aside', 'gallery', 'image', 'quote', 'status', 'video', 'audio', 'chat'
			)
		);
		add_theme_support( 'custom-header' );
		add_theme_support( 'custom-background' );
		add_editor_style();

		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 450, 600 );
		add_theme_support( 'wpclubmanager' );

		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary menu', 'vensica' ),
			)
		);

		add_theme_support(
			'html5',
			array(
				'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets',
			)
		);

		add_theme_support(
			'custom-logo',
			array(
				'height'               => 200,
				'width'                => 200,
				'flex-width'           => true,
				'flex-height'          => true,
				'unlink-homepage-logo' => true,
			)
		);

		add_theme_support( 'customize-selective-refresh-widgets' );
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'align-wide' );

		// Add custom editor font sizes.
		add_theme_support(
			'editor-font-sizes',
			array(
				array(
					'name'      => esc_html__( 'Extra small', 'vensica' ),
					'shortName' => esc_html_x( 'XS', 'Font size', 'vensica' ),
					'size'      => 16,
					'slug'      => 'extra-small',
				),
				array(
					'name'      => esc_html__( 'Small', 'vensica' ),
					'shortName' => esc_html_x( 'S', 'Font size', 'vensica' ),
					'size'      => 18,
					'slug'      => 'small',
				),
				array(
					'name'      => esc_html__( 'Normal', 'vensica' ),
					'shortName' => esc_html_x( 'M', 'Font size', 'vensica' ),
					'size'      => 20,
					'slug'      => 'normal',
				),
				array(
					'name'      => esc_html__( 'Large', 'vensica' ),
					'shortName' => esc_html_x( 'L', 'Font size', 'vensica' ),
					'size'      => 24,
					'slug'      => 'large',
				),
				array(
					'name'      => esc_html__( 'Extra large', 'vensica' ),
					'shortName' => esc_html_x( 'XL', 'Font size', 'vensica' ),
					'size'      => 40,
					'slug'      => 'extra-large',
				),
				array(
					'name'      => esc_html__( 'Huge', 'vensica' ),
					'shortName' => esc_html_x( 'XXL', 'Font size', 'vensica' ),
					'size'      => 96,
					'slug'      => 'huge',
				),
				array(
					'name'      => esc_html__( 'Gigantic', 'vensica' ),
					'shortName' => esc_html_x( 'XXXL', 'Font size', 'vensica' ),
					'size'      => 144,
					'slug'      => 'gigantic',
				),
			)
		);
		if ( is_customize_preview() ) {
			require get_template_directory() . '/inc/starter-content.php';
			add_theme_support( 'starter-content', vensica_get_starter_content() );
		}

		// Add support for responsive embedded content.
		add_theme_support( 'responsive-embeds' );

		// Add support for custom line height controls.
		add_theme_support( 'custom-line-height' );

		// Add support for experimental link color control.
		add_theme_support( 'experimental-link-color' );

		// Add support for experimental cover block spacing.
		add_theme_support( 'custom-spacing' );

		// Add support for custom units.
		// This was removed in WordPress 5.6 but is still required to properly support WP 5.5.
		add_theme_support( 'custom-units' );

		// Remove feed icon link from legacy RSS widget.
		add_filter( 'rss_widget_feed_link', '__return_false' );
	}
}
add_action( 'after_setup_theme', 'vensica_setup' );

remove_action( 'wpclubmanager_before_main_content', 'wpclubmanager_output_content_wrapper', 10);
remove_action( 'wpclubmanager_after_main_content', 'wpclubmanager_output_content_wrapper_end', 10);

add_action('wpclubmanager_before_main_content', 'vensica_theme_wrapper_start', 10);
add_action('wpclubmanager_after_main_content', 'vensica_theme_wrapper_end', 10); 
function vensica_theme_wrapper_start() {
	echo '<div class="entry-content">';
} 
function vensica_theme_wrapper_end() {
	echo '</div><!-- end .entry-content -->';
}
function vensica_widgets_init() {

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer', 'vensica' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'vensica' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'vensica_widgets_init' );


function vensica_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'vensica_content_width', 750 );
}
add_action( 'after_setup_theme', 'vensica_content_width', 0 );

// Google Fonts
if ( !function_exists( 'vensica_fonts_url' ) ) :
    function vensica_fonts_url() {
        $fonts_url = '';
        $fonts     = array();
        $subsets   = 'latin,latin-ext';

        $fonts[] = 'Barlow+Condensed:wght@400;600';
        
        if ( $fonts ) {
            $fonts_url = esc_url(add_query_arg( array(
                'family' => implode( '&', $fonts ),
                'subset' => urlencode( $subsets ),
            ), '//fonts.googleapis.com/css2' ));
        }

        return $fonts_url;
    }
endif;

function vensica_scripts() {
	// Note, the is_IE global variable is defined by WordPress and is used
	// to detect if the current browser is internet explorer.
	global $is_IE, $wp_scripts;
	if ( $is_IE ) {
		// If IE 11 or below, use a flattened stylesheet with static values replacing CSS Variables.
		wp_enqueue_style( 'vensica-style', get_template_directory_uri() . '/assets/css/ie.css', array(), wp_get_theme()->get( 'Version' ) );
	} else {
		// If not IE, use the standard stylesheet.
		wp_enqueue_style( 'vensica-style', get_template_directory_uri() . '/style.css', array(), wp_get_theme()->get( 'Version' ) );
	}
	
	// Theme fonts
	wp_enqueue_style( 'vensica-theme-fonts', vensica_fonts_url(), array(), null );

	// RTL styles.
	wp_style_add_data( 'vensica-style', 'rtl', 'replace' );

	// Threaded comment reply styles.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Register the IE11 polyfill file.
	wp_register_script(
		'vensica-ie11-polyfills-asset',
		get_template_directory_uri() . '/assets/js/polyfills.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);

	// Register the IE11 polyfill loader.
	wp_register_script(
		'vensica-ie11-polyfills',
		null,
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
	wp_add_inline_script(
		'vensica-ie11-polyfills',
		wp_get_script_polyfill(
			$wp_scripts,
			array(
				'Element.prototype.matches && Element.prototype.closest && window.NodeList && NodeList.prototype.forEach' => 'vensica-ie11-polyfills-asset',
			)
		)
	);

	// Main navigation scripts.
	if ( has_nav_menu( 'primary' ) ) {
		wp_enqueue_script(
			'vensica-primary-navigation-script',
			get_template_directory_uri() . '/assets/js/primary-navigation.js',
			array( 'vensica-ie11-polyfills' ),
			wp_get_theme()->get( 'Version' ),
			true
		);
	}

	// Responsive embeds script.
	wp_enqueue_script(
		'vensica-responsive-embeds-script',
		get_template_directory_uri() . '/assets/js/responsive-embeds.js',
		array( 'vensica-ie11-polyfills' ),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'vensica_scripts' );


function vensica_block_editor_script() {

	wp_enqueue_script( 'vensica-editor', get_theme_file_uri( '/assets/js/editor.js' ), array( 'wp-blocks', 'wp-dom' ), wp_get_theme()->get( 'Version' ), true );
}

add_action( 'enqueue_block_editor_assets', 'vensica_block_editor_script' );


function vensica_skip_link_focus_fix() {

	// If SCRIPT_DEBUG is defined and true, print the unminified file.
	if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
		echo '<script>';
		include get_template_directory() . '/assets/js/skip-link-focus-fix.js';
		echo '</script>';
	} else {
		// The following is minified via `npx terser --compress --mangle -- assets/js/skip-link-focus-fix.js`.
		?>
		<script>
		/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",(function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())}),!1);
		</script>
		<?php
	}
}
add_action( 'wp_print_footer_scripts', 'vensica_skip_link_focus_fix' );


function vensica_non_latin_languages() {
	$custom_css = vensica_get_non_latin_css( 'front-end' );

	if ( $custom_css ) {
		wp_add_inline_style( 'vensica-style', $custom_css );
	}
}
add_action( 'wp_enqueue_scripts', 'vensica_non_latin_languages' );

// SVG Icons class.
require get_template_directory() . '/classes/class-vensica-svg-icons.php';

// Enhance the theme by hooking into WordPress.
require get_template_directory() . '/inc/template-functions.php';

// Menu functions and filters.
require get_template_directory() . '/inc/menu-functions.php';

// Custom template tags for the theme.
require get_template_directory() . '/inc/template-tags.php';

// Custom template tags for the theme.
require get_template_directory() . '/inc/plugins.php';

// One click data import.
require get_template_directory() . '/classes/class-vensica-ocdi.php';

// Customizer additions.
require get_template_directory() . '/classes/class-vensica-customize.php';
new Vensica_Customize();

// WooCommerce Styles.
require get_template_directory() . '/classes/class-woo.php';

// Block Patterns.
require get_template_directory() . '/inc/block-patterns.php';

// Block Styles.
require get_template_directory() . '/inc/block-styles.php';

function vensica_customize_preview_init() {
	wp_enqueue_script(
		'vensica-customize-helpers',
		get_theme_file_uri( '/assets/js/customize-helpers.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);

	wp_enqueue_script(
		'vensica-customize-preview',
		get_theme_file_uri( '/assets/js/customize-preview.js' ),
		array( 'customize-preview', 'customize-selective-refresh', 'jquery', 'vensica-customize-helpers' ),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'customize_preview_init', 'vensica_customize_preview_init' );

function vensica_customize_controls_enqueue_scripts() {

	wp_enqueue_script(
		'vensica-customize-helpers',
		get_theme_file_uri( '/assets/js/customize-helpers.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'customize_controls_enqueue_scripts', 'vensica_customize_controls_enqueue_scripts' );

function vensica_the_html_classes() {
	$classes = apply_filters( 'vensica_html_classes', '' );
	if ( ! $classes ) {
		return;
	}
	echo 'class="' . esc_attr( $classes ) . '"';
}

function vensica_add_ie_class() {
	?>
	<script>
	if ( -1 !== navigator.userAgent.indexOf( 'MSIE' ) || -1 !== navigator.appVersion.indexOf( 'Trident/' ) ) {
		document.body.classList.add( 'is-IE' );
	}
	</script>
	<?php
}
add_action( 'wp_footer', 'vensica_add_ie_class' );

if ( ! function_exists( 'wp_get_list_item_separator' ) ) :
	function wp_get_list_item_separator() {
		/* translators: Used between list items, there is a space after the comma. */
		return __( ', ', 'vensica' );
	}
endif;

function vensica_update_wpmc_player_postmeta($post_ID, $post_after, $post_before){
	
	if ( $post_after->post_type == 'wpcm_player' ):
		if ( function_exists('wpcm_get_player_positions') ):
    		update_post_meta($post_ID, 'wpcm_position', wpcm_get_player_positions( $post_ID ));
		else:
			update_post_meta($post_ID, 'wpcm_position', 'Defender');
		endif;
	elseif ( $post_after->post_type == 'wpcm_staff' ):
		$jobs = get_the_terms( $post_ID, 'wpcm_jobs' );
		if ( is_array( $jobs ) ):
			$player_jobs = array();
			foreach ( $jobs as $job ) {
				$player_jobs[] = $job->name;
			}
			update_post_meta($post_ID, 'wpcm_position', implode( ', ', $player_jobs ));
			update_post_meta($post_ID, 'position', implode( ', ', $player_jobs ));
		else:
			update_post_meta($post_ID, 'wpcm_position', 'Manager');
			update_post_meta($post_ID, 'position', 'Manager');
		endif;
	endif;

}
add_action( 'post_updated', 'vensica_update_wpmc_player_postmeta', 10, 3 );


function vensica_register_elementor_locations( $elementor_theme_manager ) {

	$elementor_theme_manager->register_all_core_location();

}
add_action( 'elementor/theme/register_locations', 'vensica_register_elementor_locations' );
