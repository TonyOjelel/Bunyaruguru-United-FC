<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} ?>
		</main><!-- #main -->
	</div><!-- #primary -->
</div><!-- #content -->

<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) {
	get_template_part( 'template-parts/footer/site-footer' );
}
?>
</div><!-- end #page -->
<?php wp_footer(); ?>

</body>
</html>