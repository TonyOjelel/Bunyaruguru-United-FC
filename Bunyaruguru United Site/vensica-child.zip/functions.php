<?php

function vensica_child_enqueue_styles() {

    $parent_style = 'vensica-stylesheet';

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'vensica-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style )
    );
}
add_action( 'wp_enqueue_scripts', 'vensica_child_enqueue_styles' );

/* --------- Insert your customized functions on next rows --------- */

